package com.example.covidhealthservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class covidSyntoms extends AppCompatActivity {

    private ImageView imageView;
    private Button buttom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid_syntoms);

        buttom = (Button) findViewById(R.id.submit);
        buttom.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSuccess();
            }
        });

        imageView = (ImageView) findViewById(R.id.backBtn);
        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepage();
            }
        });
    }

    public  void  openSuccess(){
        Intent intent = new Intent(this, covidSyntomsResult.class);
        startActivity(intent);
    }

    public  void  openHomepage(){
        Intent intent = new Intent(this, homepage.class);
        startActivity(intent);
    }
}