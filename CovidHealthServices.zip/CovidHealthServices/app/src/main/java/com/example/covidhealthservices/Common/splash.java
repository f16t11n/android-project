package com.example.covidhealthservices.Common;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.covidhealthservices.R;

public class splash extends AppCompatActivity {

    private static  int SPLASH_SCREEN = 5000;

    // Variables
    Animation topAnim, bottomAnim;

    //call image
    ImageView splash;
    TextView logo, slogan, version;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        // Animations
        topAnim = AnimationUtils.loadAnimation(this,R.anim.top_animation);
        bottomAnim = AnimationUtils.loadAnimation(this,R.anim.bottom_animation);

        //Hooks
        splash =  findViewById(R.id.splash);
        logo =  findViewById(R.id.logo);
        slogan =  findViewById(R.id.slogan);
        version =  findViewById(R.id.version);

        splash.setAnimation(topAnim);
        logo.setAnimation(bottomAnim);
        slogan.setAnimation(bottomAnim);
        version.setAnimation(bottomAnim);


        // Home page redirect

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent homepage = new Intent(splash.this, com.example.covidhealthservices.homepage.class);
                    startActivity(homepage);
                    finish();
            }
        },SPLASH_SCREEN);
    }
}