package com.example.covidhealthservices.DRVinterface;

public interface LoadMore {
    void onLoadMore();
}
