package com.example.covidhealthservices;

public class DynamicRVModel {

    String name;

    public String getName() {
        return name;
    }

    public DynamicRVModel(String name) {
        this.name = name;
    }
}
