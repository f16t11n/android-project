package com.example.covidhealthservices;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class covidEmergency extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid_emergency);
    }
}