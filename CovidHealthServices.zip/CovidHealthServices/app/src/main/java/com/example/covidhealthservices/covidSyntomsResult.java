package com.example.covidhealthservices;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import javax.xml.transform.Result;

public class covidSyntomsResult extends AppCompatActivity {

    private  Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_covid_syntoms_result);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                TextView result = (TextView) findViewById(R.id.Result);
                Button homepage = (Button) findViewById(R.id.homepage);
                result.setVisibility(View.VISIBLE);
                homepage.setVisibility(View.VISIBLE);
            }
        },2500);

        button = (Button) findViewById(R.id.homepage);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openHomepage();
            }
        });
    }

    public  void  openHomepage(){
        Intent intent = new Intent(this, homepage.class);
        startActivity(intent);
    }

}