package com.example.covidhealthservices;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class homepage extends AppCompatActivity implements View.OnClickListener {
    public CardView card1, card2, card3, card4, card5, card6, card7, card8;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);



        card1 = (CardView) findViewById(R.id.covid_emergency);
        card2 = (CardView) findViewById(R.id.hospital);
        card3 = (CardView) findViewById(R.id.appointment);
        card4 = (CardView) findViewById(R.id.home_test);
        card5 = (CardView) findViewById(R.id.ambulance);
        card6 = (CardView) findViewById(R.id.covid_syntoms);
        card7 = (CardView) findViewById(R.id.dashboard);
        card8 = (CardView) findViewById(R.id.info);

        card1.setOnClickListener(this);
        card2.setOnClickListener(this);
        card3.setOnClickListener(this);
        card4.setOnClickListener(this);
        card5.setOnClickListener(this);
        card6.setOnClickListener(this);
        card7.setOnClickListener(this);
        card8.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()){
            case  R.id.covid_emergency:
                i = new Intent(this, covidEmergency.class);
                startActivity(i);
                break;

            case  R.id.hospital:
                i = new Intent(this, hospital.class);
                startActivity(i);
                break;

            case  R.id.appointment:
                i = new Intent(this, appointment.class);
                startActivity(i);
                break;

            case  R.id.home_test:
                i = new Intent(this, homeTest.class);
                startActivity(i);
                break;

            case  R.id.ambulance:
                i = new Intent(this, ambulance.class);
                startActivity(i);
                break;

            case  R.id.covid_syntoms:
                i = new Intent(this, covidSyntoms.class);
                startActivity(i);
                break;

            case  R.id.dashboard:
                i = new Intent(this, dashboard.class);
                startActivity(i);
                break;

            case  R.id.info:
                i = new Intent(this, info.class);
                startActivity(i);
                break;


        }
    }
}